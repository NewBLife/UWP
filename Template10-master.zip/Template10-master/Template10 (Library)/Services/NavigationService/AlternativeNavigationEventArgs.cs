﻿namespace Template10.Services.NavigationService
{
    internal class AlternativeNavigationEventArgs
    {
    }
}