﻿using System;
namespace Template10.Common
{
    public class HandledEventArgs : EventArgs
    {
        public System.Boolean Handled { get; set; }
    }
}
