﻿# If this fails to run, execute this as admin, then restart Visual Studio
# Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine


