##Template 10: Getting Started

If you want Template 10, just open up Visual Studio 2015 and search "Template 10" in the Extension Manager. After you install it, when you go File>New>Project the Template 10 project template will be in your list.

After you create a project, head to our documentation wiki and get started: <http://aka.ms/Template10>
