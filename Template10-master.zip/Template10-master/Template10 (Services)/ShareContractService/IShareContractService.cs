﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Template10.Services.ShareContractService
{
    public interface IShareContractService
    {
        void ShowUI();
    }
}
