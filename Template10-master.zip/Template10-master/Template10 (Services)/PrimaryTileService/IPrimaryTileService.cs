﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Template10.Services.PrimaryTileService
{
    public interface IPrimaryTileService
    {
        void UpdateBadge(int value);
    }
}
