﻿namespace Template10.Services.AdaptiveTiles.Model
{
    public interface ISubGroupChild : IAdaptiveTile { }
}