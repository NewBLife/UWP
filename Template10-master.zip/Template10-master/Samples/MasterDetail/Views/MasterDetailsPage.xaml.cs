﻿using Windows.UI.Xaml.Controls;

namespace Template10.Samples.MasterDetailSample.Views
{
    public sealed partial class MasterDetailsPage : Page
    {
        public MasterDetailsPage()
        {
            this.InitializeComponent();
        }
    }
}
