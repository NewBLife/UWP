﻿using Windows.UI.Xaml.Documents;

namespace Template10.Samples.DynamicFontSizeSample.Models
{
    public class Body : IBlock
    {
        public string Text { get; set; }
        public Run ToRun() => new Run { Text = Text };
    }
}
