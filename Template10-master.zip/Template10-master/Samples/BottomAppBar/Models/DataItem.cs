﻿namespace Template10.Samples.BottomAppBarSample.Models
{
    public class DataItem
    {
        public string Value1 { get; set; }
        public string Value2 { get; set; }
        public string Value3 { get; set; }
        public string Value4 { get; set; }
        public string Value5 { get; set; }
        public string Value6 { get; set; }
        public string Arrow { get; set; }
    }
}
